// Service worker disabled in no-PIN version.
