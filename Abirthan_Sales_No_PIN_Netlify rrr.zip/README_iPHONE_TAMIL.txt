K. ABIRTHAN PERSONAL SALES WEBSITE - SAFARI + NETLIFY
========================================================

ONE-TIME DEPLOY (FREE PLAN WHERE AVAILABLE)
1. On your iPhone, download K_Abirthan_Safari_Netlify_Upload.zip to Files.
2. Open Safari -> https://app.netlify.com and sign up or log in with a personal account.
3. BEFORE uploading, set Team settings > General > Visitor access > Default project visibility > Private for new projects. This is important: otherwise a new site may be publicly accessible.
4. In Safari open https://app.netlify.com/drop and select/upload the full ZIP, or an extracted website folder. (The ZIP is for Netlify upload, NOT for directly running on iPhone.)
5. After deployment, go to Project configuration > General > Visitor access > Project visibility and VERIFY Production and previews are PRIVATE (owner login required), not Public. Netlify's current credit-based Free plan can keep private projects owner-only.
6. Only once confirmed private, open the given ...netlify.app link in Safari, sign in as needed, and set your app PIN. Do not share your Netlify credentials.
7. Safari Share -> Add to Home Screen -> Open as Web App (if prompted) -> Add.

SALES DATA SAFETY
- This is a browser-only local-data version. Reports are saved on THIS iPhone/browser, NOT in a cloud sales database. It does not automatically sync across devices. If you use the Home Screen web app, storage may be different from Safari.
- Use the SAME Home Screen app every day and regularly export JSON backup to iCloud Drive/Files. Never clear website data, uninstall the app, or change browsers without backup.
- Never mistake the 6-digit in-app PIN for proper server authentication. PRIVATE Netlify project visibility is what gates access to the site itself.
- User data and reports are not embedded in this ZIP; example text shown in app is not actual sales.
- This is a Home Screen web app, not an App Store IPA.

If the free Netlify account does not offer Private visibility, STOP before entering confidential sales. A public deployment + PIN does NOT meet owner-only access.
